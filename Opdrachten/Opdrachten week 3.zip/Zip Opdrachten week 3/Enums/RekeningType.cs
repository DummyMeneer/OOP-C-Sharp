﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Opdrachten_week_3.Enums
{
    public enum RekeningType
    {
        Jongeren,
        Spaar,
        Credit,
        Debit,
        Duaal,
        Gedeeld
    }
}
